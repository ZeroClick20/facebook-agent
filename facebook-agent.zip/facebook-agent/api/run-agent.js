
const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
puppeteer.use(StealthPlugin());

module.exports = async (req, res) => {
  const { prompt } = req.body || {};

  function parsePromptToAgent(prompt) {
    return {
      tone: prompt.includes("حنونة") ? "gentle" : "neutral",
      targetUser: prompt.match(/https:\/\/facebook\.com\/[^\s]+/)?.[0],
      openingMessage: "أنا نادين، شفت بوستك وتأثرت جدًا...",
      dailyPosts: [
        "النهاردة حسيت بحاجة غريبة جوايا... مش عارفة أفسرها.",
        "فيه ناس بنقابلهم مش بنعرف ننسى وجودهم.",
      ],
    };
  }

  const agentProfile = parsePromptToAgent(prompt);

  const browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });

  const page = await browser.newPage();
  const useMobile = Math.random() > 0.5;

  if (useMobile) {
    await page.emulate(puppeteer.devices["iPhone 12"]);
  } else {
    await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64)");
  }

  await page.goto("https://facebook.com/login");
  await page.type("#email", process.env.FB_EMAIL);
  await page.type("#pass", process.env.FB_PASS);
  await Promise.all([
    page.click("button[name='login']"),
    page.waitForNavigation(),
  ]);

  if (agentProfile.targetUser) {
    await page.goto(agentProfile.targetUser);
    await page.waitForTimeout(2000);
    await page.click('div[aria-label="أضف صديقًا"]');
    await page.waitForTimeout(3000);
    await page.click('div[aria-label="رسالة"]');
    await page.keyboard.type(agentProfile.openingMessage);
    await page.keyboard.press("Enter");
  }

  await page.goto("https://facebook.com/home");
  await page.waitForTimeout(2000);
  await page.click('[aria-label="ما الذي تفكر فيه؟"]');
  await page.keyboard.type(
    agentProfile.dailyPosts[Math.floor(Math.random() * agentProfile.dailyPosts.length)]
  );
  await page.keyboard.press("Enter");

  await browser.close();
  res.status(200).send("🎯 تم تنفيذ الكيان حسب البرومبت.");
};
